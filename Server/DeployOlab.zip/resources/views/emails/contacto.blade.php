<!DOCTYPE html>
<html>
<head>
    <title>Nuevo mensaje de contacto</title>
</head>
<body>
    <h2>Nuevo mensaje de contacto</h2>
    
    <p><strong>Nombre:</strong> {{ $nombre }}</p>
    <p><strong>Correo:</strong> {{ $correo }}</p>
    <p><strong>Número:</strong> {{ $numero }}</p>
    <p><strong>Descripción:</strong></p>
    <p>{{ $descripcion }}</p>
</body>
</html> 