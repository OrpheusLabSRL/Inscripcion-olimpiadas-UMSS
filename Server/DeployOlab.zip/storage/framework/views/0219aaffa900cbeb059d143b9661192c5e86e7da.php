<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Agregar Área</h1>

    <form action="<?php echo e(route('area.agregar')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label for="idOlimpiada">Seleccionar Olimpiada:</label>
        <select id="idOlimpiada" name="idOlimpiada" required>
            <option value="">-- Selecciona una Olimpiada --</option>
            <?php $__currentLoopData = $olimpiada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($o->idOlimpiada); ?>"><?php echo e($o->nombreOlimpiada); ?> - Versión <?php echo e($o->version); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>

        <label for="nombreArea">Nombre del Área:</label>
        <input type="text" id="nombreArea" name="nombreArea" required>
        <br>

        <label for="descripcionArea">Descripción:</label>
        <textarea id="descripcionArea" name="descripcionArea"></textarea>
        <br>

        <label for="costoArea">Costo:</label>
        <input type="number" id="costoArea" name="costoArea" min="1" required>
        <br>

        <button type="submit">Guardar Área</button>
    </form>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Costo</th>
                <th>Olimpiada</th>
                <th>Estado</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($a->idArea); ?></td>
                    <td><?php echo e($a->nombreArea); ?></td>
                    <td><?php echo e($a->descripcionArea ?? 'Sin descripción'); ?></td>
                    <td><?php echo e($a->costoArea); ?></td>
                    <td><?php echo e($a->olimpiada->nombreOlimpiada); ?></td>
                    <td><?php echo e($a->estadoArea ? 'Activo' : 'Inactivo'); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Users\usser\Documents\Proyectos\OhSansi\Inscripcion-olimpiadas-UMSS\Server\resources\views/area.blade.php ENDPATH**/ ?>